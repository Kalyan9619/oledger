module.exports = {
    secret: 'secret' 
}