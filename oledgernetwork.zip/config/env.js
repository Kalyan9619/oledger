module.exports = {
    serverPORT: process.env.PORT || 5000,
}