import React, { Component } from 'react'

export default class Error404 extends Component {
    render() {
        return (
            <div>
                Sorry, Error404... ithihas Try again
            </div>
        )
    }
}
