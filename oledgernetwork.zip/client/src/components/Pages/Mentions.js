import React, { Component } from 'react'

export default class Mentions extends Component {
    render() {
        return (
            <div>
                Mentions
            </div>
        )
    }
}
