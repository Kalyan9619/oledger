import React, { Component } from 'react'

export default class SocialMedia extends Component {
    render() {
        return (
            <div>
                SocialMedia
            </div>
        )
    }
}
